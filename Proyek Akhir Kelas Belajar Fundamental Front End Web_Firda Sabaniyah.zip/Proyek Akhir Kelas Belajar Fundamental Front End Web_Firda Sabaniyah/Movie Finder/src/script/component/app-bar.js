class AppBar extends HTMLElement {

    connectedCallback() {
        this.render();
    }

    render() {
        this.innerHTML = `
        <nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top">
            <div class="container">
                <a class="navbar-brand" href="#"><strong>Nonton YUK</strong></a>
            </div>
        </nav>
        `;
    }
}

customElements.define("app-bar", AppBar);