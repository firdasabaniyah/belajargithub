

class SearchBar extends HTMLElement {
    connectedCallback() {
        this.render();
    }

    set clickEvent(event) {
        this._clickEvent = event;
        this.render();
    }

    get value() {
        return this.querySelector("#search-input").value;
    }

    render() {
        this.innerHTML = `
        <style>
        .bg{
            background : url('https://static.republika.co.id/uploads/images/inpicture_slide/pemutaran-film-di-bioskop-ilustrasi-_120523233258-396.jpg');
            padding: 15vh 0 15vh 0;
        }
        </style>

            <div class="row justify-content-center bg">
                <div class="col-md-8">
                <h1 class="text-center text-light">Nonton YUK</h1>
                <p class="text-center text-light">Nonton Yuk sebuah platform pencarian Film terkini di bioskop atau platform lainnya <br /><strong>Yuk cari dan Yuk Nonton</strong> </p>
                    <div class="input-group mb-3 container">
                        <input type="text" id="search-input" class="form-control py-4 mr-3 rounded-lg" placeholder="Silahkan Cari Judul Film"
                            aria-label="Recipient's username" aria-describedby="button-addon2" />
                        <div class="input-group-append">
                            <button class="btn btn-warning rounded-lg px-5" type="button" id="search-button">
                                Search
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <hr />
        `;

        this.querySelector("#search-button").addEventListener("click", this._clickEvent);
    }
}

customElements.define("search-bar", SearchBar);