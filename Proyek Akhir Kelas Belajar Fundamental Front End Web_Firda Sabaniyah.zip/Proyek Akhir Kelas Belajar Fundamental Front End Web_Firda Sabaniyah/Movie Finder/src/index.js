import main from '../src/script/view/main';

addEventListener('DOMContentLoaded', main);